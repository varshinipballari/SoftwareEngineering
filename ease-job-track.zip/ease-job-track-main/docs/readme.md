## Below is the ease-job-track project walk through in phases


| S No. |          Phases         |        Timelines         |      Status     |            Notes           |
|-------|-------------------------|--------------------------|-----------------|----------------------------|
|   1   | Project ideas           | Due Jan 21 at 11:59pm    |       Done      |                            |
|   2   | Repo creation           | Due Jan 21 at 11:59pm    |       Done      |                            |
|   3   | Brainstorm features     | Due Jan 28 at 11:59pm    |       Done      |                            | 
|   4   | Branching Strategy      | Best practice - All time |   In Progress   |                            |
|   5   | Story creation          | Due Jan 28 by 11:59pm    |       Done      |                            |   
|   6   | Story estimate          | Due Feb 11 by 11:59pm    |       Done      |                            |       
|   7   | Planning                | Due Feb 11 by 11:59pm    |       Done      |                            | 
|   8   | Code Reviews            | Due Feb 11 by 11:59pm    |       Done      |                            | 
|   9   | Prototype               | Due Feb 11 by 11:59pm    |       Done      |                            |          
|   10  | MVP delivered           | Due Feb 25 by 11:59pm    |   In Progress   |                            |                  
|   11  | New Features            | Due Mar 11 by 11:59pm    | Not yet started |                            | 
|   12  | Project Demo            | Final Project demo       | Not yet started |                            |      
|   13  | 360 Evaluation          | Due Mar 11 by 11:59pm    | Not yet started |                            |          
|   14  | Individual Contribution | No due date              |   In Progress   |                            | 
|   15  | Sprint Planning /Stories| All time                 |   In Progress   |                            |


