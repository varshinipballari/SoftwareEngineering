## Below is the list of features we would like our application to have

| S No. |                          Features                              |   
|-------|----------------------------------------------------------------|
|   1   | Add new job                                                   |  
|   2   | Edit current job                                              |         
|   3   | Delete current job                                            |                 
|   4   | Update status of job                                          |                   
|   5   | Developing UI for Home, Add, Edit, Delete                     |                   
|   6   | Search job by company name, role, date of interview           |                   
|   7   | Developing UI for Update and Search                           |                   
|   8   | Integrating calendar                                          |                   
|   9   | Graphical Representations of Interviews, Timeline of Interviews, Status of Application |                    
|  10   | Developing Notes section                                      |                    
|  11   | Feedback option once interview is done                        |                  
|  12   | Mobile-friendly design                                        |                    
|  13   | Multi-language support                                        |                    
|  14   | Priority                                                      |                   
|  15   | Dark mode                                                     |                    
|  16   | Notifications                                                 |                    
  
  
  
  
  
  
  
 
