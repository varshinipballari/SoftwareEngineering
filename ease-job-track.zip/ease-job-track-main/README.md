# ease-job-track
A tracker that keeps you on top of your job search and tracking 

Version : 1.0
Programming Language : Python

Python is one of the most ideal programming language for beginners, readable and also easily adaptable for new enhancements or even to automate the features in near future.
